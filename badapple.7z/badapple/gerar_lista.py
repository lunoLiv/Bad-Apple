altura = []

altura = 0

while