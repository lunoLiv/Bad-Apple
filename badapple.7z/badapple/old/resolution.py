import cv2
file_path = "C:\\Users\\2400115\\Desktop\\badapple\\old\\worst.mp4"  # change to your own video path
vid = cv2.VideoCapture(file_path)
height = vid.get(cv2.CAP_PROP_FRAME_HEIGHT)
width = vid.get(cv2.CAP_PROP_FRAME_WIDTH)

print(height,width)
