import cv2 as cv
import numpy as np
import time
import sys, os
 
def filtragem(lista):
    lista = [sum(i) for linha in lista for i in linha]
    final = []
 
    for i in lista:
        if i >= 382:
            final.append(1)
        if i < 382:
            final.append(0)
    return final
 
def criar_string(lista):
    counter = 0
    string = ''
    for i in lista:
        if i == 1:
            string += '1'
        if i == 0:
            string += '0'
    return string
 
apple = cv.VideoCapture('worst.mp4')
 
flag, frame = apple.read()
counter = 0
 
while flag:
    print(counter)

    flag, frame = apple.read()
    final = filtragem(frame.tolist())

    input(criar_string(final))

    with open(f'{counter}.txt','w') as f:
        f.write(criar_string(final))

    time.sleep(0.01)
    os.system('cls')
    
    counter += 1
