import matplotlib.pyplot as plt
import numpy as np

from a import altura, largura


plt.plot(largura, altura, '.')

plt.axis((-0, 192, 0, 144))
plt.show()